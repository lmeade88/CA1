print("Please enter distance in miles:")
miles = float(input())

kilometers = round(miles * 1.60935, 2)

print(f"The distance travelled in Kilometers is: {kilometers}")
