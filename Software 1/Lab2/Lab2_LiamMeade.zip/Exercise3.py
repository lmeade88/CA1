print("Please enter float number 1:")
float1 = float(input())

print("Please enter float number 2:")
float2 = float(input())

sum = float1 + float2
difference = abs(float1-float2)
product = float1 * float2

print(f"The sum of these numbers is {sum}")
print(f"The difference between these numbers is {difference}")
print(f"The product of these numbers is {product}")